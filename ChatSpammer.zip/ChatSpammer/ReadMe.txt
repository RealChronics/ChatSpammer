ChatSpammer is a side project of mine (Chrons The Cat#0984)
it is pretty ass i intend to make it so u can type how many textboxes/interval you want
and making the ui less shitty, but yup enjoy


Company Server: https://discord.gg/XqmMzSXUFw

Cheat Server: https://discord.gg/zDZqr4wKRx